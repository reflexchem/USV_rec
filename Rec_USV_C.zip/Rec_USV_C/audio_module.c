#include "audio_module.h"

void WriteWavHeader(FILE *file, int sampleRate, int numSamples) {
    int dataSize = numSamples * sizeof(short);
    int fileSize = 44 + dataSize;

    fwrite("RIFF", 1, 4, file);
    fwrite(&fileSize, 4, 1, file);
    fwrite("WAVE", 1, 4, file);
    fwrite("fmt ", 1, 4, file);

    int fmtSize = 16;
    short format = 1;
    short channels = 1;
    short bits = 16;
    int byteRate = sampleRate * channels * bits / 8;
    short blockAlign = channels * bits / 8;

    fwrite(&fmtSize, 4, 1, file);
    fwrite(&format, 2, 1, file);
    fwrite(&channels, 2, 1, file);
    fwrite(&sampleRate, 4, 1, file);
    fwrite(&byteRate, 4, 1, file);
    fwrite(&blockAlign, 2, 1, file);
    fwrite(&bits, 2, 1, file);

    fwrite("data", 1, 4, file);
    fwrite(&dataSize, 4, 1, file);
}

int Audio_Init(AudioContext *ctx, int micID, int sampleRate, int bufferSize) {
    ctx->sampleRate = sampleRate;
    ctx->framesPerBuffer = bufferSize;
    ctx->deviceIndex = micID;
    ctx->isRunning = 0;
    ctx->bufferIndex = 0;

    Pa_Initialize();

    ctx->inputParams.device = micID;
    ctx->inputParams.channelCount = 1;
    ctx->inputParams.sampleFormat = paInt16;
    ctx->inputParams.suggestedLatency = Pa_GetDeviceInfo(micID)->defaultLowInputLatency;
    ctx->inputParams.hostApiSpecificStreamInfo = NULL;

    return Pa_OpenStream(
        &ctx->stream,
        &ctx->inputParams,
        NULL,
        sampleRate,
        bufferSize,
        paClipOff,
        NULL,
        NULL
    );
}

int Audio_RecordToWav(AudioContext *ctx, const char *filename, int seconds) {
    int totalFrames = ctx->sampleRate * seconds;
    short buffer[ctx->framesPerBuffer];

    ctx->wavFile = fopen(filename, "wb");
    if (!ctx->wavFile) return -1;

    WriteWavHeader(ctx->wavFile, ctx->sampleRate, totalFrames);
    Pa_StartStream(ctx->stream);

    while (ctx->bufferIndex < totalFrames) {
        Pa_ReadStream(ctx->stream, buffer, ctx->framesPerBuffer);
        fwrite(buffer, sizeof(short), ctx->framesPerBuffer, ctx->wavFile);
        ctx->bufferIndex += ctx->framesPerBuffer;
    }

    return 0;
}

int Audio_Stop(AudioContext *ctx) {
    return Pa_StopStream(ctx->stream);
}

void Audio_Cleanup(AudioContext *ctx) {
    if (ctx->stream) Pa_CloseStream(ctx->stream);
    Pa_Terminate();
    if (ctx->wavFile) fclose(ctx->wavFile);
}