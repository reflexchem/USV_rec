#ifndef AUDIO_MODULE_H
#define AUDIO_MODULE_H

#include <portaudio.h>
#include <stdio.h>

typedef struct {
    PaStream *stream;
    PaStreamParameters inputParams;
    int sampleRate;
    int framesPerBuffer;
    int deviceIndex;
    int isRunning;
    FILE *wavFile;
    int bufferIndex;
} AudioContext;

int Audio_Init(AudioContext *ctx, int micID, int sampleRate, int bufferSize);
int Audio_RecordToWav(AudioContext *ctx, const char *filename, int seconds);
int Audio_Stop(AudioContext *ctx);
void Audio_Cleanup(AudioContext *ctx);

#endif