#include "audio_module.h"

int main() {
    AudioContext ctx;
    int micID = 2;  // change based on your device index

    if (Audio_Init(&ctx, micID, 44100, 256) != paNoError) {
        printf("Failed to initialize audio.\n");
        return 1;
    }

    Audio_RecordToWav(&ctx, "recording.wav", 5);  // record 5 seconds
    Audio_Stop(&ctx);
    Audio_Cleanup(&ctx);

    return 0;
}